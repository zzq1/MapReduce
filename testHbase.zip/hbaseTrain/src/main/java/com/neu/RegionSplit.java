package com.neu;

import org.apache.hadoop.hbase.util.Bytes;

public class RegionSplit {

	private String[] pointInfos1 = {
			"JLFC_FJ050_",
			"JLFC_FJ100_",
			"JLFC_FJ150_",
			"JLFC_FJ200_",
			"JLFC_FJ250_",
			"ZYFC_FJ050_",
			"ZYFC_FJ100_",
			"ZYFC_FJ150_",
			"ZYFC_FJ200_",
			"ZYFC_FJ250_",
			"WDFC_FJ050_",
			"WDFC_FJ100_",
			"WDFC_FJ150_",
			"WDFC_FJ200_",
			"WDFC_FJ250_",
			"ZRHFC_FJ050_",
			"ZRHFC_FJ100_",
			"ZRHFC_FJ150_",
			"ZRHFC_FJ200_",
			"ZRHFC_FJ250_",
			"NXFC_FJ050_",
			"NXFC_FJ100_",
			"NXFC_FJ150_",
			"NXFC_FJ200_",
			"NXFC_FJ250_"
			};
	
	private String[] pointInfos = {
			"0001",
			"0002",
			"0003",
			"0004",
			"0005",
			"0006",
			"0007",
			"0008",
			"0009",
			"0010",
			"0011",
			"0012",
			"0013",
			"0014",
			"0015",
			"0016",
			"0017",
			"0018",
			"0019",
			"0020",
			"0021",
			"0022",
			"0023",
			"0024",
			"0025",
			"0026",
			"0027",
			"0028",
			"0029"};
	
	public byte[][] split(){
		byte[][] result = new byte[pointInfos.length][];
		for(int i = 0; i < pointInfos.length; i++) {
			result[i] = Bytes.toBytes(pointInfos[i]);
			System.out.print("'" + pointInfos[i] + "'" + ",");
		}
		return result;
	}
	
	public byte[][] splitByPartition() {
		return null;
	}
	
	public static void main(String[] args) {
		RegionSplit split = new RegionSplit();
		split.split();
	}
}
