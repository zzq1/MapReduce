package com.neu;

import java.io.IOException;
import java.util.Collection;
import java.util.Map;
import java.util.NavigableMap;
import java.util.Set;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.ClusterStatus;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HRegionInfo;
import org.apache.hadoop.hbase.RegionLoad;
import org.apache.hadoop.hbase.ServerLoad;
import org.apache.hadoop.hbase.ServerName;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Admin;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.hadoop.hbase.client.MetaScanner;
import org.apache.hadoop.hbase.client.RegionLocator;
import org.apache.hadoop.hbase.util.Bytes;

public class HBaseOprations {

	public static void main(String[] args) throws IOException {
		Configuration conf = HBaseConfiguration.create();
//		System.out.println(conf.toString());
		HBaseHelper helper = HBaseHelper.getHelper(conf);
		helper.splitRegion("24261034a736c06db96172b6f648f0bb", Bytes.toBytes("0120151025"));
		//helper.mergerRegions("92e57c211228ae4847dac3a02a51e684", "c059a4fee33246a00c95136319d9215f");
		createTable(helper);
		//getRegionSize(conf);
	}
	
	public static void createTable(HBaseHelper helper) throws IOException{
		//helper.dropTable("FANINFO");// 删除表
		RegionSplit rSplit = new RegionSplit();
		byte[][] splitKeys = rSplit.split();
		TableName tablename = TableName.valueOf("TEST");//新建表
	    helper.createTable(tablename, 1, splitKeys, "INFO");
	    helper.createTable(tablename, 1, "INFO");
	}
	
	public static void getRegionsInfo(Configuration conf) throws IOException{
		Connection connection = ConnectionFactory.createConnection(conf);
		TableName tablename = TableName.valueOf(Bytes.toBytes("faninfo8"));
		NavigableMap<HRegionInfo, ServerName> regionMap 
			= MetaScanner.allTableRegions(connection, tablename);
		Set<HRegionInfo> set = regionMap.keySet();
		TableName tableName = TableName.valueOf(Bytes.toBytes("faninfo8"));
		RegionLocator regionLoc = connection.getRegionLocator(tableName);
	}
	
	public static void getRegionSize(Configuration conf) throws IOException{
		Connection connection = ConnectionFactory.createConnection(conf);
		Admin admin = connection.getAdmin();
		ClusterStatus status = admin.getClusterStatus();
		Collection<ServerName> snList = status.getServers();
		int totalSize = 0;
		for (ServerName sn : snList) {
			System.out.println(sn.getServerName());
			ServerLoad sl = status.getLoad(sn);
			int storeFileSize = sl.getStorefileSizeInMB();// RS大小
			Map<byte[], RegionLoad> rlMap = sl.getRegionsLoad();
			Set<byte[]> rlKeys = rlMap.keySet();
			for (byte[] bs : rlKeys) {
				RegionLoad rl = rlMap.get(bs);
				String regionName = rl.getNameAsString();
				if(regionName.substring(0, regionName.indexOf(",")).equals("FANPOINTINFO")) {
					int regionSize = rl.getStorefileSizeMB();
					totalSize += regionSize;
					System.out.println(regionSize + "MB");
				}
			}
		}
		System.out.println("总大小=" + totalSize + "MB");
	}

}
